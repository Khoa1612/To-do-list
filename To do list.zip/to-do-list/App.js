import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  FlatList,
  StyleSheet,
  Switch,
} from 'react-native';

const TodoApp = () => {
  const [tasks, setTasks] = useState([]);
  const [originalTasks, setOriginalTasks] = useState([]);
  const [newTask, setNewTask] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [query, setQuery] = useState('');

  

  const addTask = (category) => {
    if (newTask.trim() !== '') {
      const newTaskItem = { id: Date.now(), text: newTask, done: false, category: category };
      setOriginalTasks([...originalTasks, newTaskItem]);
      setTasks([...tasks, newTaskItem]);
      setNewTask('');
    }
  };

  const toggleDone = (id) => {
    const updatedTasks = tasks.map((task) =>
      task.id === id ? { ...task, done: !task.done } : task
    );
    setTasks(updatedTasks);
  };

  const deleteTask = (id) => {
    const updatedTasks = tasks.filter((task) => task.id !== id);
    setOriginalTasks(updatedTasks); // Update originalTasks as well
    setTasks(updatedTasks);
  };

  const filterTasksByCategory = (category) => {
    setSelectedCategory(category);
  };

  const searchTasks = (query) => {
    if (query === '') {
      setTasks(originalTasks); // Display originalTasks when query is empty
    } else {
      const filteredTasks = originalTasks.filter(
        (task) =>
          task.text.toLowerCase().includes(query.toLowerCase()) ||
          task.category.toLowerCase().includes(query.toLowerCase())
      );
      setTasks(filteredTasks);
    }
    setQuery(query);
  };

  const renderTask = ({ item }) => {
    if (selectedCategory === 'All' || item.category === selectedCategory) {
      return (
        <View style={[styles.taskContainer, item.done && styles.doneTask]}>
          <Text style={[styles.taskText, item.done && styles.doneTaskText]}>{item.text}</Text>
          <View style={styles.buttonContainer}>
            <Switch value={item.done} onValueChange={() => toggleDone(item.id)} />
            <TouchableOpacity style={styles.deleteButton} onPress={() => deleteTask(item.id)}>
              <Text style={styles.deleteButtonText}>DELETE</Text>
            </TouchableOpacity>
          </View>
        </View>
      );
    } else {
      return null;
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>TODO App</Text>
      <View style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          value={newTask}
          onChangeText={(text) => setNewTask(text)}
          placeholder="Enter task..."
        />
        <TouchableOpacity style={styles.addButton} onPress={() => addTask(selectedCategory)}>
          <Text style={styles.addButtonText}>ADD ITEM</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.categoryContainer}>
        <Text style={styles.categoryTitle}>Loại công việc: </Text>
        <TouchableOpacity
          style={[styles.categoryButton, selectedCategory === 'All' && styles.selectedCategory]}
          onPress={() => filterTasksByCategory('All')}
        >
          <Text style={styles.categoryButtonText}>All</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.categoryButton, selectedCategory === 'Work' && styles.selectedCategory]}
          onPress={() => filterTasksByCategory('Work')}
        >
          <Text style={styles.categoryButtonText}>Work</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.categoryButton, selectedCategory === 'Personal' && styles.selectedCategory]}
          onPress={() => filterTasksByCategory('Personal')}
        >
          <Text style={styles.categoryButtonText}>Personal</Text>
        </TouchableOpacity>
      </View>

      <TextInput
        style={styles.searchInput}
        placeholder="Search tasks..."
        value={query}
        onChangeText={(text) => searchTasks(text)}
      />

      <FlatList
        data={tasks}
        renderItem={renderTask}
        keyExtractor={(item) => item.id.toString()}
        style={styles.taskList}
        nestedScrollEnabled={true}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#f5f5f5',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10,
    textAlign: 'center',
    backgroundColor: 'lightgray',
    paddingBottom: 28,
  },
  inputContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  input: {
    flex: 1,
    height: 35,
    borderColor: 'gray',
    borderWidth: 1,
    paddingHorizontal: 8,
    marginRight: 8,
  },
  addButton: {
    backgroundColor: 'brown',
    borderRadius: 4,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 8,
  },
  addButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
  categoryContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  categoryTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginRight: 8,
  },
  categoryButton: {
    backgroundColor: 'gray',
    borderRadius: 4,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 8,
    marginRight: 8,
  },
  categoryButtonText: {
    color: 'white',
  },
  selectedCategory: {
    backgroundColor: 'brown',
  },
  searchInput: {
    height: 35,
    borderColor: 'gray',
    borderWidth: 1,
    paddingHorizontal: 8,
    marginBottom: 8,
  },
  taskList: {
    marginTop: 10,
    backgroundColor: '#ecf0f1',
    borderRadius: 8,
  },
  taskContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: 'white',
    borderRadius: 4,
    padding: 12,
    marginBottom: 8,
  },
  taskText: {},
  doneTask: {
    backgroundColor: '#dfe6e9',
  },
  doneTaskText: {
    textDecorationLine: 'line-through',
    color: '#636e72',
  },
  buttonContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  deleteButton: {
    backgroundColor: 'red',
    borderRadius: 4,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 8,
    marginLeft: 8,
  },
  deleteButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
});

export default TodoApp;
